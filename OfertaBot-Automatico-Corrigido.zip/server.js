require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SHOPEE_URL = "https://open-api.affiliate.shopee.com.br/graphql";
const DATA_DIR = path.join(__dirname, "data");
const CONFIG_FILE = path.join(DATA_DIR, "automation.json");
const HISTORY_FILE = path.join(DATA_DIR, "history.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const DEFAULT_CONFIG = {
  enabled: String(process.env.AUTO_ENABLED || "false").toLowerCase() === "true",
  keyword: process.env.AUTO_KEYWORD || "ofertas",
  intervalMinutes: Number(process.env.AUTO_INTERVAL_MINUTES || 60),
  template: process.env.AUTO_TEMPLATE || "🔥 OFERTA! {produto} — {preco} 🔗 {link}",
  limit: Number(process.env.AUTO_LIMIT || 10),
  nextRun: null
};

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}
function config() {
  const c = readJson(CONFIG_FILE, DEFAULT_CONFIG);
  c.intervalMinutes = Math.min(Math.max(Number(c.intervalMinutes) || 60, 5), 1440);
  c.limit = Math.min(Math.max(Number(c.limit) || 10, 1), 50);
  return c;
}
function saveConfig(c) { writeJson(CONFIG_FILE, c); }
function history() { return readJson(HISTORY_FILE, []); }
function saveHistory(h) { writeJson(HISTORY_FILE, h.slice(-200)); }

app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname,"public")));

function shopeeSort(value) {
  return ({relevancia:1,vendidos:2,preco_desc:3,preco_asc:4,comissao:5}[value] || 1);
}
function money(v) {
  if(v===null||v===undefined||v==="") return "Preço não informado";
  const n=Number(String(v).replace(",","."));
  return Number.isFinite(n) ? n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"}) : String(v);
}
async function shopeeRequest(query) {
  const appId=process.env.SHOPEE_APP_ID, secret=process.env.SHOPEE_APP_SECRET;
  if(!appId||!secret) { const e=new Error("Shopee não configurada."); e.status=503; throw e; }
  const payload=JSON.stringify({query});
  const timestamp=Math.floor(Date.now()/1000).toString();
  const signature=crypto.createHash("sha256").update(appId+timestamp+payload+secret,"utf8").digest("hex");
  const r=await fetch(SHOPEE_URL,{method:"POST",headers:{
    "Content-Type":"application/json",
    "Authorization":`SHA256 Credential=${appId}, Timestamp=${timestamp}, Signature=${signature}`
  },body:payload});
  const d=await r.json().catch(()=>({}));
  if(!r.ok||d.errors?.length){const e=new Error(d.errors?.[0]?.message||`Shopee HTTP ${r.status}`);e.status=r.status||502;throw e;}
  return d;
}
async function searchShopee(keyword,limit=10,sort="relevancia") {
  const safe=JSON.stringify(String(keyword).slice(0,120));
  const query=`{ productOfferV2(keyword:${safe},listType:0,sortType:${shopeeSort(sort)},page:1,limit:${limit}) {
    nodes { itemId productName productLink offerLink imageUrl priceMin priceMax priceDiscountRate sales ratingStar commissionRate commission shopName }
    pageInfo { page limit hasNextPage }
  }}`;
  const d=await shopeeRequest(query);
  return (d.data?.productOfferV2?.nodes||[]).map(o=>({
    itemId:String(o.itemId||""),
    name:o.productName||"Produto",
    price:o.priceMin&&o.priceMax&&o.priceMin!==o.priceMax?`${money(o.priceMin)} a ${money(o.priceMax)}`:money(o.priceMin??o.priceMax),
    link:o.offerLink||o.productLink||"",
    image:o.imageUrl||"",
    commission:o.commission?money(o.commission):(o.commissionRate?String(o.commissionRate):""),
    sales:o.sales??null, rating:o.ratingStar??null, shop:o.shopName||""
  }));
}

async function sendWhatsApp(message) {
  const token=process.env.WA_ACCESS_TOKEN, phoneId=process.env.WA_PHONE_NUMBER_ID, groupId=process.env.WA_GROUP_ID;
  if(!token||!phoneId||!groupId){const e=new Error("WhatsApp automático não configurado. Preencha WA_ACCESS_TOKEN, WA_PHONE_NUMBER_ID e WA_GROUP_ID.");e.status=503;throw e;}
  const version=process.env.WA_GRAPH_VERSION||"v23.0";
  const r=await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`,{
    method:"POST",headers:{"Authorization":`Bearer ${token}`,"Content-Type":"application/json"},
    body:JSON.stringify({messaging_product:"whatsapp",recipient_type:"group",to:groupId,type:"text",text:{preview_url:true,body:message}})
  });
  const d=await r.json().catch(()=>({}));
  if(!r.ok){const e=new Error(d.error?.message||`WhatsApp HTTP ${r.status}`);e.status=r.status;throw e;}
  return d;
}
function buildMessage(template,o){
  return String(template)
    .replaceAll("{produto}",o.name||"Produto")
    .replaceAll("{preco}",o.price||"Confira o preço")
    .replaceAll("{link}",o.link||"")
    .slice(0,4000);
}
function alreadySent(itemId,link) {
  return history().some(x => (itemId && x.itemId===itemId) || (link && x.link===link));
}

let running=false;
let timer=null;

async function runAutomation(reason="timer") {
  if(running) return {skipped:true,message:"Já existe uma execução em andamento."};
  const c=config();
  if(!c.enabled && reason==="timer") return {skipped:true,message:"Automação pausada."};
  running=true;
  try {
    if(!c.keyword) throw new Error("Defina uma palavra-chave.");
    const offers=await searchShopee(c.keyword,c.limit,"relevancia");
    const fresh=offers.find(o=>o.link&&!alreadySent(o.itemId,o.link));
    if(!fresh) {
      return {sent:false,message:"Nenhuma oferta nova encontrada. Vou tentar novamente no próximo intervalo."};
    }
    const message=buildMessage(c.template,fresh);
    await sendWhatsApp(message);
    const h=history();
    h.push({itemId:fresh.itemId,name:fresh.name,price:fresh.price,link:fresh.link,sentAt:new Date().toISOString(),reason});
    saveHistory(h);
    return {sent:true,message:`Oferta enviada: ${fresh.name}`,offer:fresh};
  } finally { running=false; }
}

function schedule() {
  if(timer) clearInterval(timer);
  const c=config();
  if(!c.enabled){ c.nextRun=null; saveConfig(c); return; }
  const ms=c.intervalMinutes*60*1000;
  c.nextRun=new Date(Date.now()+ms).toISOString(); saveConfig(c);
  timer=setInterval(async()=>{
    const current=config();
    if(!current.enabled){schedule();return;}
    try {
      await runAutomation("timer");
    } catch(e) { console.error("[AUTOMATION]",e.message); }
    const cc=config(); cc.nextRun=new Date(Date.now()+cc.intervalMinutes*60*1000).toISOString(); saveConfig(cc);
  },ms);
}

app.get("/api/health",(req,res)=>res.json({
  ok:true, shopee:Boolean(process.env.SHOPEE_APP_ID&&process.env.SHOPEE_APP_SECRET),
  whatsapp:Boolean(process.env.WA_ACCESS_TOKEN&&process.env.WA_PHONE_NUMBER_ID&&process.env.WA_GROUP_ID)
}));

app.post("/api/offers",async(req,res)=>{
  try{
    const keyword=String(req.body.keyword||"").trim();
    const limit=Math.min(Math.max(Number(req.body.limit)||5,1),50);
    if(!keyword)return res.status(400).json({message:"Digite uma palavra-chave."});
    res.json({offers:await searchShopee(keyword,limit,req.body.sort||"relevancia")});
  }catch(e){console.error(e);res.status(e.status||500).json({message:e.message||"Erro interno."});}
});

app.get("/api/automation/status",(req,res)=>{
  const c=config();
  res.json({...c,shopee:Boolean(process.env.SHOPEE_APP_ID&&process.env.SHOPEE_APP_SECRET),whatsapp:Boolean(process.env.WA_ACCESS_TOKEN&&process.env.WA_PHONE_NUMBER_ID&&process.env.WA_GROUP_ID),running});
});
app.get("/api/automation/history",(req,res)=>res.json({items:history().slice(-20).reverse()}));

app.post("/api/automation/config",(req,res)=>{
  const c=config();
  if(req.body.keyword!==undefined)c.keyword=String(req.body.keyword).trim().slice(0,120);
  if(req.body.intervalMinutes!==undefined)c.intervalMinutes=Math.min(Math.max(Number(req.body.intervalMinutes)||60,5),1440);
  if(req.body.limit!==undefined)c.limit=Math.min(Math.max(Number(req.body.limit)||10,1),50);
  if(req.body.template!==undefined)c.template=String(req.body.template).slice(0,4000);
  if(req.body.enabled!==undefined)c.enabled=Boolean(req.body.enabled);
  saveConfig(c); schedule();
  res.json({message:c.enabled?"Automação ativada e salva.":"Configuração salva.",...config()});
});
app.post("/api/automation/toggle",(req,res)=>{
  const c=config(); c.enabled=!c.enabled; saveConfig(c); schedule();
  res.json({message:c.enabled?"Automação ativada.":"Automação pausada.",...c});
});
app.post("/api/automation/run-now",async(req,res)=>{
  try{const d=await runAutomation("manual");res.json(d);}
  catch(e){console.error(e);res.status(e.status||500).json({message:e.message||"Falha na execução."});}
});

app.get("/*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

process.on("SIGINT",()=>{if(timer)clearInterval(timer);process.exit(0)});
process.on("SIGTERM",()=>{if(timer)clearInterval(timer);process.exit(0)});

app.listen(PORT,()=>{console.log(`OfertaBot rodando em http://localhost:${PORT}`);schedule();});
